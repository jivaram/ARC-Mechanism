
////using weak and unowned key world we control ARC machanism 

import UIKit

class Father {
    var name: Child?
    var age: Int
    init(name: Child? = nil, age: Int) {
        self.name = name
        self.age = age
        print("\(self) allocated")
    }
    deinit {
        print("\(self) deallocated")
    }
}

class Child {
    weak var name: Father?
    var age: Int
    init(name: Father? = nil, age: Int) {
        self.name = name
        self.age = age
        print("\(self) allocated")
    }
    deinit {
        print("\(self) deallocated")
    }
}

var father: Father? = Father(name: nil, age: 65)
var child: Child? = Child(name: nil, age: 25)
father?.name = child // here is strong refrance between father and child classes
child?.name = father
father = nil
child = nil
